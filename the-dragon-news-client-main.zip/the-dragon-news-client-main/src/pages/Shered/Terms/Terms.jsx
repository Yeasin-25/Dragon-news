import React from 'react';
import { Link } from 'react-router-dom';

const Terms = () => {
    return (
        <div>
            <h2>Terms and Condition</h2>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima aliquam quibusdam dignissimos veniam, vitae consectetur, reprehenderit odio, ullam possimus veritatis id maiores? Possimus officiis quae ducimus deleniti velit ipsum sed similique optio, ratione assumenda dicta minima ipsam, illum nobis omnis? Voluptatem explicabo perferendis officia iusto dolores cumque omnis voluptatum et enim, adipisci sunt aut modi ut animi ratione quisquam. Asperiores ex explicabo perspiciatis hic itaque architecto sit, soluta voluptates ipsum deserunt rerum amet minima odio aspernatur magnam nisi iste pariatur! Quam sequi dolorum voluptatibus recusandae repudiandae consectetur sunt dolores eius quos ipsam, neque animi, veniam a molestias? Porro, officiis eius harum nihil et optio deleniti accusamus similique corporis veritatis, suscipit, voluptas aspernatur expedita deserunt ipsam error doloremque quod eveniet. Ducimus dolor, ea corporis vero harum id dicta ab soluta earum necessitatibus hic dolorem molestias dolore explicabo placeat sequi ad optio! Nesciunt possimus omnis debitis nostrum fugiat dolore est, porro minus voluptate inventore totam eligendi quibusdam. Repellat reprehenderit iusto modi nisi, temporibus porro ullam iure vero, incidunt nihil cum, at nostrum autem! Repellat voluptates reiciendis harum ab eius quod similique sit sint doloremque corrupti quo facilis sunt, voluptate aspernatur veritatis laboriosam, tempora architecto illum nemo rem? Assumenda culpa enim odit quisquam!</p>
            <p>
                Go back
                <Link to="/register">Register</Link>
            </p>
        </div>
    );
};

export default Terms;