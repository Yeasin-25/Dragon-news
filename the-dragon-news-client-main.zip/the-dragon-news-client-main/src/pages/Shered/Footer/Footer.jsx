import React from 'react';

const Footer = () => {
    return (
        <div>
            <h5 className='text-center'>copyright my news</h5>
        </div>
    );
};

export default Footer;